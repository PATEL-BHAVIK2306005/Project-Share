import os
import sys
import uuid
from datetime import datetime

# Ensure project directory is in Python module search path
PROJECT_DIR = os.path.abspath(os.path.dirname(__file__))
if PROJECT_DIR not in sys.path:
    sys.path.insert(0, PROJECT_DIR)

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    session,
    jsonify
)
from config import Config
from models import db, User, LoginAuditLog, PaymentTransaction
from utils.email_service import send_login_notification, send_payment_receipt_email, AUDIT_JSON_PATH

app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
db.init_app(app)

# Initialize Razorpay Client (Open-Source Python SDK for Demo / Test Mode)
try:
    import razorpay
    razorpay_client = razorpay.Client(
        auth=(app.config.get('RAZORPAY_KEY_ID', ''), app.config.get('RAZORPAY_KEY_SECRET', ''))
    )
    print(f"[PAYMENT GATEWAY] Open-source Razorpay SDK loaded successfully (Key: {app.config.get('RAZORPAY_KEY_ID')[:12]}...)")
except Exception as e:
    razorpay_client = None
    print(f"[PAYMENT GATEWAY NOTICE] Razorpay running in demo simulation mode: {e}")

# Ensure database tables exist
with app.app_context():
    db.create_all()
    # Seed default demonstration account if none exists
    try:
        if not User.query.filter_by(username='admin').first():
            demo_user = User(
                fullname='Demo Administrator',
                username='admin',
                email='admin@majestic.com',
                phone='+91 9876543210'
            )
            demo_user.set_password('admin123')
            db.session.add(demo_user)
            db.session.commit()
            print("[SETUP] Seeded default demo user: admin / admin123")
    except Exception as e:
        print(f"[SETUP NOTICE] {e}")


# ====================================================================
# TASK 1: Website Integration Routes
# ====================================================================

@app.route('/')
def home():
    """
    Task 1: Home page integration
    Task 3: Display processed registration data on Home page
    """
    # Fetch all registered users to display on Home page (Task 3 requirement)
    all_users = User.query.order_by(User.id.desc()).all()
    
    # Check if a newly registered user ID was set in session
    latest_user_id = session.pop('just_registered_user_id', None)
    latest_user = None
    if latest_user_id:
        latest_user = db.session.get(User, latest_user_id)
    elif all_users:
        latest_user = all_users[0]  # Show the most recent user

    return render_template('index.html', active_page='home', all_users=all_users, latest_user=latest_user)


@app.route('/favicon.ico')
def favicon():
    """Handle browser favicon request"""
    return redirect(url_for('static', filename='images/logo-2.png'))


@app.route('/about')
def about():
    """Task 1: About page route"""
    return render_template('about.html', active_page='about')


@app.route('/blog')
def blog():
    """Task 1: Blog page route"""
    return render_template('blog.html', active_page='blog')


@app.route('/pages')
def pages():
    """Task 1: Pages & UI elements route"""
    return render_template('pages.html', active_page='pages')


@app.route('/gallery')
def gallery():
    """Task 1: Gallery page route"""
    return render_template('gallery.html', active_page='gallery')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    """Task 1: Contact page route & message submission"""
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        flash(f"Thank you, <strong>{name}</strong>! Your message has been received. Our team will contact you at <em>{email}</em>.", "success")
        return redirect(url_for('contact'))
    return render_template('contact.html', active_page='contact')


@app.route('/single')
def single():
    """Task 1: Single article detail page route"""
    return render_template('single.html', active_page='blog')


# ====================================================================
# TASK 2: Login and Registration Pages
# TASK 3: Registration Data Display
# TASK 4: Email Notification During Login
# ====================================================================

@app.route('/register', methods=['GET', 'POST'])
def register():
    """
    Task 2: Registration page styled after Contact page
    Task 3: Process registration data and redirect to Home page for display
    """
    if request.method == 'POST':
        fullname = request.form.get('fullname', '').strip()
        username = request.form.get('username', '').strip().lower()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # Basic validations
        if not fullname or not username or not email or not password:
            flash("All mandatory fields (*) must be completed.", "danger")
            return render_template('register.html', active_page='register')

        if password != confirm_password:
            flash("Passwords do not match! Please retype your password.", "danger")
            return render_template('register.html', active_page='register')

        if len(password) < 6:
            flash("Password must be at least 6 characters long.", "warning")
            return render_template('register.html', active_page='register')

        # Check existing user/email
        existing_user = User.query.filter((User.username == username) | (User.email == email)).first()
        if existing_user:
            if existing_user.username == username:
                flash(f"Username '<strong>{username}</strong>' is already registered. Please choose another username.", "warning")
            else:
                flash(f"Email '<strong>{email}</strong>' is already registered. Please login instead.", "info")
            return render_template('register.html', active_page='register')

        # Create new user record
        try:
            new_user = User(
                fullname=fullname,
                username=username,
                email=email,
                phone=phone
            )
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()

            # Store in session to highlight on Home page
            session['just_registered_user_id'] = new_user.id
            flash(
                f"Registration Successful! Welcome <strong>{fullname}</strong>. "
                f"Your submitted details are displayed below in the Member Directory.", 
                "success"
            )
            return redirect(url_for('home', _anchor='registered-data-section'))
        except Exception as e:
            db.session.rollback()
            flash(f"Database error during registration: {str(e)}", "danger")
            return render_template('register.html', active_page='register')

    return render_template('register.html', active_page='register')


@app.route('/user/delete/<int:user_id>', methods=['GET', 'POST'])
def delete_user(user_id):
    """Delete a user from the directory"""
    user = db.session.get(User, user_id)
    if user:
        name = user.fullname
        # If deleted user is logged in, clear session
        if session.get('user_id') == user.id:
            session.pop('user_id', None)
            session.pop('user_name', None)
            session.pop('user_username', None)
            session.pop('user_email', None)
        db.session.delete(user)
        db.session.commit()
        flash(f"User <strong>{name}</strong> was successfully removed from the database.", "success")
    else:
        flash("User record not found or already deleted.", "warning")
    return redirect(url_for('home', _anchor='registered-data-section'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Task 2: Login page styled after Contact page
    Task 4: Email notification during login (valid and invalid credentials)
    """
    if request.method == 'POST':
        login_identifier = request.form.get('login_identifier', '').strip().lower()
        password = request.form.get('password', '')
        ip_address = request.remote_addr or '127.0.0.1'

        # Find user by username or email
        user = User.query.filter(
            (User.username == login_identifier) | (User.email == login_identifier)
        ).first()

        # Check credentials
        if user and user.check_password(password):
            # ----------------------------------------------------
            # VALID LOGIN SCENARIO (Task 4)
            # ----------------------------------------------------
            session['user_id'] = user.id
            session['user_name'] = user.fullname
            session['user_username'] = user.username
            session['user_email'] = user.email

            # Dispatch success notification email
            email_res = send_login_notification(
                recipient_email=user.email,
                recipient_name=user.fullname,
                is_valid=True,
                ip_address=ip_address,
                username=user.username
            )

            # Record in database audit log
            audit = LoginAuditLog(
                username_or_email=login_identifier,
                status='SUCCESS',
                ip_address=ip_address,
                email_sent_to=user.email,
                email_subject=str(email_res.get('subject', 'Security Alert')),
                email_delivery_status=str(email_res.get('delivery_status', 'SIMULATED')),
                email_body_preview=str(email_res.get('body_preview', ''))
            )
            db.session.add(audit)
            db.session.commit()

            flash(
                f"<strong>Authentication Succeeded!</strong> Welcome back, {user.fullname}.<br>"
                f"<span class='glyphicon glyphicon-envelope'></span> <strong>Security Notification:</strong> "
                f"A success alert was dispatched to <em>{user.email}</em> ({email_res.get('delivery_status', 'SENT')}).",
                "success"
            )
            return redirect(url_for('home'))

        else:
            # ----------------------------------------------------
            # INVALID LOGIN SCENARIO (Task 4)
            # ----------------------------------------------------
            # Determine target recipient email: if user exists but bad password, send to user's email;
            # otherwise if login_identifier has '@', send to that email, else to fallback demo email
            recipient_email = None
            recipient_name = "User"
            target_username = login_identifier

            if user:
                recipient_email = user.email
                recipient_name = user.fullname
                target_username = user.username
            elif '@' in login_identifier:
                recipient_email = login_identifier
                recipient_name = login_identifier.split('@')[0].capitalize()
            else:
                recipient_email = f"{login_identifier}@example.com"

            # Dispatch security warning email
            email_res = send_login_notification(
                recipient_email=recipient_email,
                recipient_name=recipient_name,
                is_valid=False,
                ip_address=ip_address,
                username=target_username
            )

            # Record in database audit log
            audit = LoginAuditLog(
                username_or_email=login_identifier,
                status='FAILED',
                ip_address=ip_address,
                email_sent_to=recipient_email,
                email_subject=str(email_res.get('subject', 'Security Warning')),
                email_delivery_status=str(email_res.get('delivery_status', 'SIMULATED')),
                email_body_preview=str(email_res.get('body_preview', ''))
            )
            db.session.add(audit)
            db.session.commit()

            flash(
                f"<strong>Authentication Failed:</strong> Invalid credentials provided for <em>'{login_identifier}'</em>.<br>"
                f"<span class='glyphicon glyphicon-alert'></span> <strong>Security Alert:</strong> "
                f"An intrusion warning email was dispatched to <em>{recipient_email}</em> ({email_res.get('delivery_status', 'SENT')}). "
                f"Review it under <a href='{url_for('audit_logs')}' style='color: #856404; font-weight: bold; text-decoration: underline;'>Audit Logs</a>.",
                "danger"
            )
            return render_template('login.html', active_page='login')

    return render_template('login.html', active_page='login')


@app.route('/logout')
def logout():
    """Clear session on logout"""
    name = session.pop('user_name', 'User')
    session.pop('user_id', None)
    session.pop('user_username', None)
    session.pop('user_email', None)
    flash(f"You have been successfully logged out. Goodbye, {name}!", "info")
    return redirect(url_for('login'))


# ====================================================================
# TASK 5: Payment Gateway Integration Demonstration (Razorpay Open-Source SDK)
# ====================================================================

@app.route('/payment')
def payment():
    """Task 5: Payment Gateway Demonstration Page (Razorpay Open-Source Demo Mode)"""
    razorpay_key_id = app.config.get('RAZORPAY_KEY_ID', 'rzp_test_DemoKey1234567890')
    company_name = app.config.get('COMPANY_NAME', 'Majestic Interior Studio')
    return render_template(
        'payment.html',
        active_page='payment',
        razorpay_key_id=razorpay_key_id,
        company_name=company_name
    )


@app.route('/payment/razorpay/update-keys', methods=['POST'])
def update_razorpay_keys():
    """Update Razorpay API keys dynamically for live evaluation"""
    global razorpay_client
    try:
        data = request.get_json(force=True) if request.is_json else request.form
        key_id = data.get('key_id', '').strip()
        key_secret = data.get('key_secret', '').strip()
        if not key_id:
            return jsonify({'success': False, 'error': 'Key ID is required'}), 400
        
        app.config['RAZORPAY_KEY_ID'] = key_id
        if key_secret:
            app.config['RAZORPAY_KEY_SECRET'] = key_secret
        
        import razorpay
        razorpay_client = razorpay.Client(auth=(key_id, app.config.get('RAZORPAY_KEY_SECRET', '')))
        print(f"[PAYMENT GATEWAY] Updated Razorpay credentials: {key_id}")
        return jsonify({'success': True, 'key_id': key_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/payment/razorpay/create-order', methods=['POST'])
def razorpay_create_order():
    """
    Creates a Razorpay Order payload.
    If Key Secret is valid, creates order on Razorpay cloud.
    Otherwise returns key_id and amount for direct client-side checkout.
    """
    try:
        data = request.get_json(force=True) if request.is_json else request.form
        customer_name = data.get('customer_name', 'Student Developer').strip()
        customer_email = data.get('customer_email', 'student@itmslsbu.ac.in').strip()
        service_name = data.get('service_name', 'Executive 3D Makeover')
        amount = float(data.get('amount', 2999))
        amount_in_paise = int(amount * 100)
        currency = app.config.get('RAZORPAY_CURRENCY', 'INR')
        key_id = app.config.get('RAZORPAY_KEY_ID', 'rzp_test_U1j3x2J8S2KEE2')

        receipt_id = f"rcpt_{uuid.uuid4().hex[:8]}"
        order_id = None

        # Attempt creation with Razorpay official cloud SDK if secret is configured
        if razorpay_client:
            try:
                rzp_order = razorpay_client.order.create({
                    "amount": amount_in_paise,
                    "currency": currency,
                    "receipt": receipt_id,
                    "notes": {
                        "service": service_name,
                        "customer_name": customer_name,
                        "customer_email": customer_email
                    }
                })
                order_id = rzp_order.get('id')
                print(f"[RAZORPAY] Created cloud order: {order_id}")
            except Exception as rzp_err:
                print(f"[RAZORPAY NOTICE] Server-side order creation skipped ({rzp_err}). Using client-side checkout.")

        return jsonify({
            'success': True,
            'order_id': order_id,  # None if secret is not set, checkout.js handles client-side
            'amount': amount_in_paise,
            'amount_in_rupees': amount,
            'currency': currency,
            'key_id': key_id,
            'service_name': service_name,
            'customer_name': customer_name,
            'customer_email': customer_email,
            'company_name': app.config.get('COMPANY_NAME', 'Majestic Interior Studio')
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/payment/razorpay/verify', methods=['POST'])
def razorpay_verify():
    """
    Task 5: Razorpay Callback & Verification Endpoint
    Verifies Razorpay payment signature (HMAC-SHA256) and stores transaction.
    """
    razorpay_payment_id = request.form.get('razorpay_payment_id', '').strip()
    razorpay_order_id = request.form.get('razorpay_order_id', '').strip()
    razorpay_signature = request.form.get('razorpay_signature', '').strip()
    
    customer_name = request.form.get('customer_name', 'Student Developer').strip()
    customer_email = request.form.get('customer_email', 'student@itmslsbu.ac.in').strip()
    service_name = request.form.get('service_name', 'Executive 3D Makeover')
    amount = float(request.form.get('amount', 2999))
    payment_method = request.form.get('payment_method', 'Razorpay Open-Source Gateway')
    simulation_outcome = request.form.get('simulation_outcome', 'SUCCESS')

    # Simulation decline or missing payment id
    if simulation_outcome == 'FAILURE' or not razorpay_payment_id:
        fail_txn_id = razorpay_payment_id or f"pay_failed_{uuid.uuid4().hex[:10]}"
        txn = PaymentTransaction(
            transaction_id=fail_txn_id,
            order_id=razorpay_order_id or f"order_{uuid.uuid4().hex[:10]}",
            customer_name=customer_name,
            customer_email=customer_email,
            service_name=service_name,
            amount=amount,
            payment_method=payment_method,
            status='FAILED',
            error_message='Razorpay transaction declined by issuing bank (Insufficient balance / invalid OTP simulation).'
        )
        db.session.add(txn)
        db.session.commit()
        return redirect(url_for('payment_failure', txn_id=fail_txn_id))

    # Cryptographic signature verification with Razorpay open-source library
    is_valid = True
    key_secret = app.config.get('RAZORPAY_KEY_SECRET', '')
    if razorpay_client and not key_secret.startswith('DemoSecretKey') and razorpay_signature:
        try:
            razorpay_client.utility.verify_payment_signature({
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': razorpay_payment_id,
                'razorpay_signature': razorpay_signature
            })
            is_valid = True
        except Exception as sig_err:
            print(f"[RAZORPAY VERIFICATION] Signature verification error: {sig_err}")
            is_valid = False
    else:
        is_valid = (simulation_outcome == 'SUCCESS')

    if is_valid:
        txn = PaymentTransaction(
            transaction_id=razorpay_payment_id,
            order_id=razorpay_order_id,
            customer_name=customer_name,
            customer_email=customer_email,
            service_name=service_name,
            amount=amount,
            payment_method=f"Razorpay ({payment_method})",
            status='SUCCESS',
            error_message=None
        )
        db.session.add(txn)
        db.session.commit()

        # Send official payment receipt email to client
        try:
            send_payment_receipt_email(txn)
        except Exception as mail_err:
            print(f"[RECEIPT EMAIL WARNING] {mail_err}")

        return redirect(url_for('payment_success', txn_id=razorpay_payment_id))
    else:
        txn = PaymentTransaction(
            transaction_id=razorpay_payment_id,
            order_id=razorpay_order_id,
            customer_name=customer_name,
            customer_email=customer_email,
            service_name=service_name,
            amount=amount,
            payment_method=f"Razorpay ({payment_method})",
            status='FAILED',
            error_message='Razorpay HMAC-SHA256 signature verification failed (Integrity mismatch).'
        )
        db.session.add(txn)
        db.session.commit()
        return redirect(url_for('payment_failure', txn_id=razorpay_payment_id))


@app.route('/payment/process', methods=['POST'])
def process_payment():
    """
    Task 5: Direct Form fallback endpoint for instant viva demonstrations
    """
    customer_name = request.form.get('customer_name', 'Student Developer').strip()
    customer_email = request.form.get('customer_email', 'student@itmslsbu.ac.in').strip()
    service_name = request.form.get('service_name', 'Executive 3D Makeover')
    amount = float(request.form.get('amount', 2999))
    payment_method = request.form.get('payment_method', 'Razorpay Test Mode')
    outcome = request.form.get('simulation_outcome', 'SUCCESS')

    # Generate gateway unique IDs formatted in Razorpay style
    transaction_id = f"pay_{uuid.uuid4().hex[:14]}"
    order_id = f"order_{uuid.uuid4().hex[:14]}"

    if outcome == 'SUCCESS':
        txn = PaymentTransaction(
            transaction_id=transaction_id,
            order_id=order_id,
            customer_name=customer_name,
            customer_email=customer_email,
            service_name=service_name,
            amount=amount,
            payment_method=payment_method,
            status='SUCCESS',
            error_message=None
        )
        db.session.add(txn)
        db.session.commit()

        # Send official payment receipt email to client
        try:
            send_payment_receipt_email(txn)
        except Exception as mail_err:
            print(f"[RECEIPT EMAIL WARNING] {mail_err}")

        return redirect(url_for('payment_success', txn_id=transaction_id))
    else:
        txn = PaymentTransaction(
            transaction_id=transaction_id,
            order_id=order_id,
            customer_name=customer_name,
            customer_email=customer_email,
            service_name=service_name,
            amount=amount,
            payment_method=payment_method,
            status='FAILED',
            error_message='Razorpay Test Mode authorization declined by issuing bank (Simulated card failure).'
        )
        db.session.add(txn)
        db.session.commit()
        return redirect(url_for('payment_failure', txn_id=transaction_id))


@app.route('/payment/success/<txn_id>')
def payment_success(txn_id):
    """Task 5: Payment Success response page"""
    txn = PaymentTransaction.query.filter_by(transaction_id=txn_id).first_or_404()
    return render_template('payment_success.html', active_page='payment', txn=txn)


@app.route('/payment/failure/<txn_id>')
def payment_failure(txn_id):
    """Task 5: Payment Failure response page"""
    txn = PaymentTransaction.query.filter_by(transaction_id=txn_id).first_or_404()
    return render_template('payment_failure.html', active_page='payment', txn=txn)


# ====================================================================
# Additional Utilities for Viva Demonstration
# ====================================================================

@app.route('/audit-logs')
def audit_logs():
    """Inspect all email notifications and authentication attempts"""
    logs = LoginAuditLog.query.order_by(LoginAuditLog.id.desc()).all()
    return render_template('audit_logs.html', active_page='audit_logs', logs=logs)


@app.route('/clear-audit-logs')
def clear_audit_logs():
    """Clear audit logs for fresh test runs"""
    LoginAuditLog.query.delete()
    db.session.commit()
    flash("Audit logs have been reset for testing.", "info")
    return redirect(url_for('audit_logs'))


@app.route('/api/status')
def api_status():
    """JSON health status endpoint for inspection"""
    db_engine = db.engine.name
    total_users = User.query.count()
    total_txns = PaymentTransaction.query.count()
    total_logs = LoginAuditLog.query.count()
    return jsonify({
        'status': 'ONLINE',
        'course': 'B.Tech Semester-5 AY 2026-2027 Winter-2026',
        'subject': 'PBL Python Framework',
        'institution': 'ITM SLS BU, Vadodara',
        'database_backend': db_engine,
        'registered_users_count': total_users,
        'payment_transactions_count': total_txns,
        'login_audit_logs_count': total_logs
    })


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print("=" * 70)
    print("  MAJESTIC WEB PORTAL - PBL PYTHON FRAMEWORK SUBMISSION")
    print(f"  Running on: http://127.0.0.1:{port}")
    print("=" * 70)
    app.run(debug=True, host='0.0.0.0', port=port)
