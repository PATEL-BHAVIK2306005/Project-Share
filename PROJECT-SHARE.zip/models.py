from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    fullname = db.Column(db.String(120), nullable=False)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __init__(self, fullname="", username="", email="", phone="", password_hash="", created_at=None, **kwargs):
        super().__init__(**kwargs)
        self.fullname = fullname
        self.username = username
        self.email = email
        self.phone = phone
        self.password_hash = password_hash
        if created_at:
            self.created_at = created_at

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def to_dict(self):
        return {
            'id': self.id,
            'fullname': self.fullname,
            'username': self.username,
            'email': self.email,
            'phone': self.phone,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }


class LoginAuditLog(db.Model):
    __tablename__ = 'login_audit_logs'

    id = db.Column(db.Integer, primary_key=True)
    username_or_email = db.Column(db.String(120), nullable=False)
    status = db.Column(db.String(20), nullable=False)  # SUCCESS or FAILED
    ip_address = db.Column(db.String(50), default='127.0.0.1')
    email_sent_to = db.Column(db.String(120), nullable=True)
    email_subject = db.Column(db.String(255), nullable=True)
    email_delivery_status = db.Column(db.String(50), default='SIMULATED')  # DELIVERED, SIMULATED, FAILED
    email_body_preview = db.Column(db.Text, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __init__(self, username_or_email="", status="SUCCESS", ip_address="127.0.0.1", 
                 email_sent_to="", email_subject="", email_delivery_status="SIMULATED", 
                 email_body_preview="", timestamp=None, **kwargs):
        super().__init__(**kwargs)
        self.username_or_email = username_or_email
        self.status = status
        self.ip_address = ip_address
        self.email_sent_to = email_sent_to
        self.email_subject = email_subject
        self.email_delivery_status = email_delivery_status
        self.email_body_preview = email_body_preview
        if timestamp:
            self.timestamp = timestamp

    def to_dict(self):
        return {
            'id': self.id,
            'username_or_email': self.username_or_email,
            'status': self.status,
            'ip_address': self.ip_address,
            'email_sent_to': self.email_sent_to,
            'email_subject': self.email_subject,
            'email_delivery_status': self.email_delivery_status,
            'email_body_preview': self.email_body_preview,
            'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        }


class PaymentTransaction(db.Model):
    __tablename__ = 'payment_transactions'

    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.String(50), unique=True, nullable=False)
    order_id = db.Column(db.String(50), nullable=False)
    customer_name = db.Column(db.String(120), nullable=False)
    customer_email = db.Column(db.String(120), nullable=False)
    service_name = db.Column(db.String(150), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(10), default='INR')
    payment_method = db.Column(db.String(50), default='Credit Card')
    status = db.Column(db.String(20), nullable=False)  # SUCCESS, FAILED, PENDING
    error_message = db.Column(db.String(255), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    def __init__(self, transaction_id="", order_id="", customer_name="", customer_email="",
                 service_name="", amount=0.0, currency="INR", payment_method="Credit Card",
                 status="SUCCESS", error_message=None, timestamp=None, **kwargs):
        super().__init__(**kwargs)
        self.transaction_id = transaction_id
        self.order_id = order_id
        self.customer_name = customer_name
        self.customer_email = customer_email
        self.service_name = service_name
        self.amount = amount
        self.currency = currency
        self.payment_method = payment_method
        self.status = status
        self.error_message = error_message
        if timestamp:
            self.timestamp = timestamp

    def to_dict(self):
        return {
            'transaction_id': self.transaction_id,
            'order_id': self.order_id,
            'customer_name': self.customer_name,
            'customer_email': self.customer_email,
            'service_name': self.service_name,
            'amount': self.amount,
            'currency': self.currency,
            'payment_method': self.payment_method,
            'status': self.status,
            'error_message': self.error_message,
            'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        }
