@echo off
title PBL Python Framework - Web Portal (ITM SLS BU)
color 0A
cd /d "%~dp0"

echo ======================================================================
echo   ITM SLS BARODA UNIVERSITY, VADODARA
echo   School of Computer Science, Engineering ^& Technology
echo   B.Tech Semester-5 (Winter 2026) | PBL Python Framework
echo   Regular Final Viva-Voce Submission
echo ======================================================================
echo.

echo [1/3] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not configured in your system PATH!
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b
)
python --version

echo.
echo [2/3] Checking and verifying required Python packages...
python -c "import flask, flask_sqlalchemy, pymysql, cryptography, pptx" >nul 2>&1
if errorlevel 1 (
    echo [SETUP] Missing packages detected! Installing all required dependencies automatically...
    echo.
    python -m pip install flask flask-sqlalchemy pymysql cryptography python-pptx
    if errorlevel 1 (
        echo [ERROR] Failed to install required packages. Check your internet connection.
        pause
        exit /b
    )
    echo.
    echo [SUCCESS] All packages successfully installed!
) else (
    echo [OK] All required packages are already installed (Flask, MySQL, SQLAlchemy, Cryptography, PPTX).
)

echo.
echo [3/3] Launching Web GUI and Flask Server...
echo Portal URL: http://127.0.0.1:5000
echo.

:: Automatically open browser after 2 seconds
start /min cmd /c "timeout /t 2 /nobreak >nul && start http://127.0.0.1:5000"

:: Start the Flask Application
python app.py

pause
