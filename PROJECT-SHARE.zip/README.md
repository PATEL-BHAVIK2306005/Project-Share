# ITM SLS Baroda University - PBL Python Framework Final Submission

**Subject:** PBL Python Framework  
**Semester:** B.Tech Semester-5 (Winter 2026), AY 2026-2027  
**Department:** School of Computer Science, Engineering & Technology, Vadodara  
**Folder Name:** `Master-Login-FOrm-Submission`  

---

## Quick Start Instructions

### Option 1: One-Click Launch (Windows)
Double-click `run.bat` inside this folder. It will automatically check your Python environment and start the Flask web server.

### Option 2: Command Line Launch
1. Ensure your dependencies are installed:
   ```bash
   pip install flask flask-sqlalchemy pymysql cryptography python-pptx
   ```
2. (Recommended) Start **Apache** and **MySQL** in your **XAMPP Control Panel**.
3. Start the application:
   ```bash
   python app.py
   ```
4. Open your web browser and navigate to:
   ```
   http://127.0.0.1:5000
   ```

---

## Submission Artifacts in this Folder

- `app.py`: Main Flask application implementing all 5 PBL tasks and routes.
- `config.py`: Configuration with dynamic XAMPP MySQL detection and SQLite fallback.
- `models.py`: Database models (`User`, `LoginAuditLog`, `PaymentTransaction`).
- `database_setup.sql`: Complete MySQL schema ready to import into phpMyAdmin.
- `PBL_Python_Framework_Submission.pptx`: 12-Slide PowerPoint presentation prepared for the viva-voce exam.
- `VIVA_VOCE_GUIDE.md`: Comprehensive Viva-Voce preparation guide with top questions & answers.
- `run.bat`: Windows executable batch launcher.
- `templates/`: Jinja2 templates (index, about, blog, pages, gallery, contact, single, login, register, payment, payment_success, payment_failure, audit_logs).
- `static/`: Complete styling, scripts, fonts, and images from the Majestic template.
- `utils/`: `email_service.py` handling Task 4 security notification dispatches.

---

## Task Verification Checklist

- [x] **Task 1: Website Integration Using Flask** (All template pages integrated with clean routes)
- [x] **Task 2: Login & Registration Pages** (Styled after the contact page layout with form validation)
- [x] **Task 3: Registration Data Display** (Registered user data is processed and presented dynamically on the Home page)
- [x] **Task 4: Email Notification During Login** (Automated notification email on valid login; security alert email on invalid credentials)
- [x] **Task 5: Payment Gateway Integration Demonstration** (Full payment initiation, cryptographic tokens, and dedicated success/failure result pages)
- [x] **XAMPP MySQL Backend Integration** (Integrated with `majestic_db` on port 3306)
- [x] **PowerPoint Presentation (PPT)** (`PBL_Python_Framework_Submission.pptx` ready for defense)
