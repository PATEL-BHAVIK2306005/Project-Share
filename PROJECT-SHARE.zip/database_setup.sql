-- ====================================================================
-- PBL Python Framework - Database Setup Script for XAMPP MySQL
-- Institute: ITM SLS BU, Vadodara | B.Tech Semester-5 AY 2026-2027
-- Database: majestic_db
-- ====================================================================

CREATE DATABASE IF NOT EXISTS `majestic_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `majestic_db`;

-- --------------------------------------------------------------------
-- Table 1: users (Task 2 & Task 3)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `fullname` VARCHAR(120) NOT NULL,
    `username` VARCHAR(80) NOT NULL UNIQUE,
    `email` VARCHAR(120) NOT NULL UNIQUE,
    `phone` VARCHAR(20) DEFAULT NULL,
    `password_hash` VARCHAR(255) NOT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------------
-- Table 2: login_audit_logs (Task 4)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_audit_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username_or_email` VARCHAR(120) NOT NULL,
    `status` VARCHAR(20) NOT NULL,
    `ip_address` VARCHAR(50) DEFAULT '127.0.0.1',
    `email_sent_to` VARCHAR(120) DEFAULT NULL,
    `email_subject` VARCHAR(255) DEFAULT NULL,
    `email_delivery_status` VARCHAR(50) DEFAULT 'SIMULATED',
    `email_body_preview` TEXT DEFAULT NULL,
    `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------------
-- Table 3: payment_transactions (Task 5)
-- --------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payment_transactions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `transaction_id` VARCHAR(50) NOT NULL UNIQUE,
    `order_id` VARCHAR(50) NOT NULL,
    `customer_name` VARCHAR(120) NOT NULL,
    `customer_email` VARCHAR(120) NOT NULL,
    `service_name` VARCHAR(150) NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `currency` VARCHAR(10) DEFAULT 'INR',
    `payment_method` VARCHAR(50) DEFAULT 'Credit Card',
    `status` VARCHAR(20) NOT NULL,
    `error_message` VARCHAR(255) DEFAULT NULL,
    `timestamp` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------------------
-- Seed Initial Demo Data for Evaluation
-- --------------------------------------------------------------------
-- Default Test User: admin / admin123
-- Password hash generated using Werkzeug scrypt/pbkdf2
INSERT INTO `users` (`fullname`, `username`, `email`, `phone`, `password_hash`, `created_at`)
VALUES 
('Demonstration Admin', 'admin', 'admin@majestic.com', '+91 9876543210', 'scrypt:32768:8:1$xPZ6XhF3Kq9vjWcE$d4e8c156f687483120b666a70a83cb0f741160bb638d380e224e758a5da9e979aebcbe98628b03046bc3847e0aa06cba68482da268ea8b5daecab91220a02cb4', NOW())
ON DUPLICATE KEY UPDATE `fullname`=`fullname`;
