import os
import pymysql

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

def get_database_uri():
    """
    Checks for XAMPP MySQL on localhost:3306.
    If MySQL is available, ensures 'majestic_db' exists and returns MySQL URI.
    Otherwise falls back safely to SQLite.
    """
    mysql_user = os.environ.get('MYSQL_USER', 'root')
    mysql_password = os.environ.get('MYSQL_PASSWORD', '')
    mysql_host = os.environ.get('MYSQL_HOST', 'localhost')
    mysql_port = int(os.environ.get('MYSQL_PORT', 3306))
    mysql_db = os.environ.get('MYSQL_DB', 'majestic_db')

    # Explicit override via environment variable
    if 'DATABASE_URL' in os.environ:
        return os.environ['DATABASE_URL']

    # Test MySQL connection
    try:
        conn = pymysql.connect(
            host=mysql_host,
            user=mysql_user,
            password=mysql_password,
            port=mysql_port,
            connect_timeout=2
        )
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{mysql_db}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        conn.commit()
        conn.close()
        # Return PyMySQL URI for Flask-SQLAlchemy
        auth_part = f"{mysql_user}:{mysql_password}@" if mysql_password else f"{mysql_user}@"
        print(f"[DATABASE] Connected successfully to XAMPP MySQL: {mysql_db} on {mysql_host}:{mysql_port}")
        return f"mysql+pymysql://{auth_part}{mysql_host}:{mysql_port}/{mysql_db}"
    except Exception as e:
        sqlite_path = os.path.join(BASE_DIR, "instance", "pbl_framework.db")
        os.makedirs(os.path.join(BASE_DIR, "instance"), exist_ok=True)
        print(f"[DATABASE NOTICE] XAMPP MySQL not reachable ({e}). Using local SQLite: {sqlite_path}")
        print("[TIP] Start Apache & MySQL in XAMPP Control Panel to switch to live XAMPP MySQL automatically.")
        return f"sqlite:///{sqlite_path}"


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'itm-sls-bu-pbl-python-framework-secret-key-2026')
    SQLALCHEMY_DATABASE_URI = get_database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SEND_FILE_MAX_AGE_DEFAULT = 0
    TEMPLATES_AUTO_RELOAD = True
    
    # SMTP Email Configuration (Gmail App Password)
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'True').lower() in ['true', '1', 't']
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME', 'bhavik.itmbu@gmail.com')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', 'qlyanvagtiyhtple')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER', 'bhavik.itmbu@gmail.com')

    # Razorpay Payment Gateway Configuration (Test / Demo Mode)
    RAZORPAY_KEY_ID = os.environ.get('RAZORPAY_KEY_ID', 'rzp_test_U1j3x2J8S2KEE2')
    RAZORPAY_KEY_SECRET = os.environ.get('RAZORPAY_KEY_SECRET', 'DemoSecretKey9876543210')
    RAZORPAY_CURRENCY = 'INR'
    COMPANY_NAME = 'Majestic Interior Design Studio'
