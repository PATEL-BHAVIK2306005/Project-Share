import os
import smtplib
import json
from datetime import datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import current_app

LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), '..', 'audit_logs')
os.makedirs(LOG_DIR, exist_ok=True)
AUDIT_JSON_PATH = os.path.join(LOG_DIR, 'email_audit.json')

def send_login_notification(recipient_email, recipient_name, is_valid, ip_address='127.0.0.1', username=None):
    """
    Sends simple text + emoji login notification email (No HTML).
    - is_valid=True: Successful login notification
    - is_valid=False: Security warning alert
    """
    timestamp_str = datetime.now().strftime('%d %b %Y, %I:%M:%S %p')
    user_handle = username or recipient_email

    if is_valid:
        subject = "🔐 Majestic Security: Successful Login Detected"
        plain_body = f"""🔐 MAJESTIC PORTAL - SECURITY NOTIFICATION

Hello {recipient_name} 👋,

✅ SUCCESSFUL LOGIN DETECTED
--------------------------------------------------
👤 Account: @{user_handle}
⏰ Timestamp: {timestamp_str}
🌐 Origin IP: {ip_address}
🛡️ Status: Authentication Verified (Access Granted)
--------------------------------------------------

✨ If this was you, you can safely disregard this message.
⚠️ If you did NOT log in, please secure your account and reset your password immediately.

Best regards,
Majestic Security System 🏛️
School of CSE | ITM SLS Baroda University, Vadodara
"""
    else:
        subject = "🚨 Security Alert: Failed Login Attempt Detected"
        plain_body = f"""🚨 MAJESTIC PORTAL - SECURITY ALERT

Hello {recipient_name} 👋,

❌ FAILED LOGIN ATTEMPT DETECTED
--------------------------------------------------
👤 Account: @{user_handle}
⏰ Timestamp: {timestamp_str}
🌐 Origin IP: {ip_address}
⚠️ Status: Invalid Password / Credentials Rejected
--------------------------------------------------

🔔 An unsuccessful attempt to sign in with your credentials was detected.
🛡️ If this was not you, someone may be trying to access your account.

Best regards,
Majestic Security System 🏛️
School of CSE | ITM SLS Baroda University, Vadodara
"""

    delivery_status = "SIMULATED"
    mail_error = None

    # Retrieve SMTP configuration
    mail_username = current_app.config.get('MAIL_USERNAME')
    mail_password = current_app.config.get('MAIL_PASSWORD')
    mail_server = current_app.config.get('MAIL_SERVER')
    mail_port = current_app.config.get('MAIL_PORT', 587)
    use_tls = current_app.config.get('MAIL_USE_TLS', True)
    sender = current_app.config.get('MAIL_DEFAULT_SENDER', 'bhavik.itmbu@gmail.com')

    if mail_username and mail_password and mail_server:
        try:
            clean_password = mail_password.replace(' ', '')
            
            # Simple text + emoji email (No HTML)
            msg = MIMEText(plain_body, 'plain', 'utf-8')
            msg['Subject'] = subject
            msg['From'] = sender
            msg['To'] = recipient_email

            with smtplib.SMTP(mail_server, mail_port, timeout=10) as server:
                if use_tls:
                    server.starttls()
                server.login(mail_username, clean_password)
                server.sendmail(sender, [recipient_email], msg.as_string())
                
            delivery_status = f"DELIVERED (via {mail_server})"
            print(f"[EMAIL NOTIFICATION] Sent text+emoji email to {recipient_email}")
        except Exception as e:
            delivery_status = f"SIMULATED (SMTP notice: {str(e)})"
            mail_error = str(e)
            print(f"[EMAIL NOTIFICATION NOTICE] Could not send via live SMTP: {e}. Saved to audit logs.")
    else:
        delivery_status = "SIMULATED (Saved in Audit Logs)"

    # Append to JSON audit file
    record = {
        'timestamp': timestamp_str,
        'recipient_email': recipient_email,
        'recipient_name': recipient_name,
        'is_valid': is_valid,
        'subject': subject,
        'status': 'VALID LOGIN' if is_valid else 'FAILED ATTEMPT',
        'delivery_status': delivery_status,
        'ip_address': ip_address,
        'preview': plain_body
    }

    try:
        data = []
        if os.path.exists(AUDIT_JSON_PATH):
            with open(AUDIT_JSON_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
        data.insert(0, record)
        with open(AUDIT_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"Error persisting email audit JSON: {e}")

    return {
        'subject': subject,
        'delivery_status': delivery_status,
        'body_preview': plain_body,
        'error': mail_error
    }


def send_payment_receipt_email(txn):
    """
    Sends an attractive official payment confirmation & receipt email to the client
    after a successful Razorpay transaction.
    """
    timestamp_str = txn.timestamp.strftime('%d-%b-%Y, %I:%M:%S %p')
    subject = f"🧾 Official Payment Receipt: {txn.service_name} (₹{txn.amount:,.2f}) - Razorpay Verified"

    # Plain text version
    plain_body = f"""====================================================================
MAJESTIC INTERIOR DESIGN STUDIO - PAYMENT RECEIPT & TAX INVOICE
====================================================================

Dear {txn.customer_name},

Thank you for your business! Your payment for '{txn.service_name}' has been successfully authorized and captured via Razorpay Secure Gateway.

--------------------------------------------------------------------
TRANSACTION DETAILS:
--------------------------------------------------------------------
Receipt / Order Ref : {txn.order_id}
Razorpay Payment ID : {txn.transaction_id}
Customer Name       : {txn.customer_name}
Customer Email      : {txn.customer_email}
Service Description : {txn.service_name}
Total Amount Paid   : INR ₹{txn.amount:,.2f}
Payment Method      : {txn.payment_method}
Transaction Status  : SUCCESS / CAPTURED (200 OK)
Date & Timestamp    : {timestamp_str}
--------------------------------------------------------------------

This is an electronically generated official receipt. 
If you have any questions, reply directly to this email.

Best Regards,
Majestic Interior Design Studio & E-Commerce Division
School of Computer Science & Engineering | ITM SLS Baroda University, Vadodara
====================================================================
"""

    # Rich HTML Version (Mobile & Desktop Friendly)
    html_body = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  body {{ font-family: 'Helvetica Neue', Arial, sans-serif; background: #f4f6f9; margin: 0; padding: 20px; }}
  .container {{ max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.08); border: 1px solid #e1e8ed; }}
  .header {{ background: #0c2340; color: #ffffff; padding: 25px 30px; text-align: center; }}
  .header h1 {{ margin: 0; font-size: 22px; font-weight: 700; letter-spacing: 0.5px; }}
  .header p {{ margin: 5px 0 0; font-size: 13px; color: #93c5fd; }}
  .badge-success {{ display: inline-block; background: #22c55e; color: #ffffff; padding: 6px 16px; border-radius: 20px; font-size: 13px; font-weight: bold; margin-top: 15px; }}
  .content {{ padding: 30px; }}
  .greeting {{ font-size: 16px; color: #334155; margin-bottom: 20px; }}
  .table {{ width: 100%; border-collapse: collapse; margin-top: 15px; }}
  .table th {{ text-align: left; padding: 10px 12px; background: #f8fafc; color: #64748b; font-size: 12px; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; width: 40%; }}
  .table td {{ padding: 10px 12px; color: #1e293b; font-size: 14px; border-bottom: 1px solid #e2e8f0; }}
  .amount-row {{ background: #f0fdf4 !important; }}
  .amount-row td {{ font-size: 18px !important; font-weight: bold; color: #15803d !important; }}
  .footer {{ background: #f8fafc; padding: 20px 30px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #e2e8f0; }}
  .brand-logo {{ font-size: 26px; font-weight: 800; color: #ffffff; letter-spacing: 1px; }}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="brand-logo">MAJESTIC</div>
      <h1>Official Payment Receipt</h1>
      <p>Interior Design Services &amp; Turnkey Consultancy</p>
      <div class="badge-success">✓ PAYMENT CAPTURED (200 OK)</div>
    </div>
    
    <div class="content">
      <div class="greeting">
        Hello <strong>{txn.customer_name}</strong>,<br>
        Thank you for choosing Majestic! Your payment has been verified and confirmed by Razorpay.
      </div>
      
      <table class="table">
        <tr>
          <th>Razorpay Payment ID</th>
          <td><code style="background: #f1f5f9; padding: 3px 6px; border-radius: 4px; color: #0c2340; font-weight: bold;">{txn.transaction_id}</code></td>
        </tr>
        <tr>
          <th>Order Reference</th>
          <td><code style="background: #f1f5f9; padding: 3px 6px; border-radius: 4px; color: #475569;">{txn.order_id}</code></td>
        </tr>
        <tr>
          <th>Service Package</th>
          <td><strong>{txn.service_name}</strong></td>
        </tr>
        <tr class="amount-row">
          <th>Total Amount Paid</th>
          <td>₹{txn.amount:,.2f} INR</td>
        </tr>
        <tr>
          <th>Payment Channel</th>
          <td>{txn.payment_method}</td>
        </tr>
        <tr>
          <th>Date &amp; Time</th>
          <td>{timestamp_str}</td>
        </tr>
        <tr>
          <th>Security Verification</th>
          <td><span style="color: #2563eb; font-weight: bold;">✓ Razorpay Test Sandbox Verified</span></td>
        </tr>
      </table>
      
      <p style="font-size: 13px; color: #64748b; margin-top: 25px; line-height: 1.5;">
        Our design specialist team has begun reviewing your project requirements. You can present this digital receipt for all subsequent consultations.
      </p>
    </div>
    
    <div class="footer">
      <strong>Majestic Interior Design Studio</strong><br>
      School of Computer Science &amp; Engineering | ITM SLS Baroda University, Vadodara<br>
      <span style="font-size: 11px; color: #94a3b8;">This is an automated transaction receipt dispatched via Gmail SMTP (Port 587 TLS).</span>
    </div>
  </div>
</body>
</html>
"""

    delivery_status = "SIMULATED"
    mail_error = None

    # Retrieve SMTP configuration
    mail_username = current_app.config.get('MAIL_USERNAME')
    mail_password = current_app.config.get('MAIL_PASSWORD')
    mail_server = current_app.config.get('MAIL_SERVER')
    mail_port = current_app.config.get('MAIL_PORT', 587)
    use_tls = current_app.config.get('MAIL_USE_TLS', True)
    sender = current_app.config.get('MAIL_DEFAULT_SENDER', 'bhavik.itmbu@gmail.com')

    if mail_username and mail_password and mail_server:
        try:
            clean_password = mail_password.replace(' ', '')

            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = f"Majestic Billing <{sender}>"
            msg['To'] = txn.customer_email

            part1 = MIMEText(plain_body, 'plain', 'utf-8')
            part2 = MIMEText(html_body, 'html', 'utf-8')
            msg.attach(part1)
            msg.attach(part2)

            with smtplib.SMTP(mail_server, mail_port, timeout=10) as server:
                if use_tls:
                    server.starttls()
                server.login(mail_username, clean_password)
                server.sendmail(sender, [txn.customer_email], msg.as_string())

            delivery_status = f"DELIVERED (via {mail_server})"
            print(f"[RECEIPT DISPATCH] Dispatched payment receipt email to {txn.customer_email}!")
        except Exception as e:
            delivery_status = f"SIMULATED (SMTP notice: {str(e)})"
            mail_error = str(e)
            print(f"[RECEIPT DISPATCH NOTICE] Could not send via live SMTP: {e}. Saved to audit logs.")
    else:
        delivery_status = "SIMULATED (Saved in Audit Logs)"

    # Record in audit trail
    audit_record = {
        'timestamp': timestamp_str,
        'recipient_email': txn.customer_email,
        'recipient_name': txn.customer_name,
        'is_valid': True,
        'subject': subject,
        'status': f"PAYMENT RECEIPT (₹{txn.amount})",
        'delivery_status': delivery_status,
        'ip_address': 'Razorpay Webhook',
        'preview': plain_body
    }

    try:
        data = []
        if os.path.exists(AUDIT_JSON_PATH):
            with open(AUDIT_JSON_PATH, 'r', encoding='utf-8') as f:
                data = json.load(f)
        data.insert(0, audit_record)
        with open(AUDIT_JSON_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f"Error persisting receipt audit JSON: {e}")

    return {
        'subject': subject,
        'delivery_status': delivery_status,
        'body_preview': plain_body,
        'error': mail_error
    }
